from flask import Flask, render_template, url_for, request,session, redirect
import mysql.connector, re, pickle

import pandas as pd
import numpy as np
from sklearn import svm
from sklearn.feature_extraction.text import TfidfTransformer,TfidfVectorizer, CountVectorizer

#STOP WORDS, STEMMING & LEMMATIZINGpip

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer

nltk.download('wordnet')
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('stopwords')
nltk.download('omw-1.4')

from nltk.corpus import wordnet
from nltk import FreqDist, pos_tag

#stop words

stop_words = list(stopwords.words('english'))
stop_words

#adding few more words to suit functionality
stop_words.extend(["ex","husband","wife","girl","boy","n't",'thank','get','please','san','diego',
                   'hi','hello','im','wa','ha','ive','would','like','know','also','let',
                   '2020','name','one','yet','june','said','two','aug','oct','jan','dec','july',
                   '-','january','april','robert','etc','nov','mesa','brown','andrew','jean','kim'])

def get_wordnet_pos(word):
   tag = pos_tag([word])[0][1][0].upper()
   #print(tag)
   tag_dict = {"J": wordnet.ADJ,
                "N": wordnet.NOUN,
                "V": wordnet.VERB,
                "R": wordnet.ADV}
   return tag_dict.get(tag, wordnet.NOUN)


def Vader_sentiment_scores(sentence):
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

    sid_obj = SentimentIntensityAnalyzer()

    sentiment_dict = sid_obj.polarity_scores(sentence)

    if sentiment_dict['compound'] > 0.2 :
        return("Positive")
  
    else :
        return("Negative")  

app = Flask(__name__)

conn = mysql.connector.connect(host="localhost", user="root", password="", database="test")
cursor = conn.cursor()
app.secret_key='secret'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html', username= session['username'])

@app.route('/login', methods =['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        cursor.execute('SELECT * FROM users_data WHERE email = %s AND password = %s', (username, password, ))
        account = cursor.fetchone()
        recordNo = cursor.rowcount
        if recordNo!=0:
            session['loggedin'] = True
            session['username'] = account[1]
            session['email'] = account[4]
            msg = 'Logged in successfully !'
            return redirect(url_for('about'))
        else:
            msg = 'Incorrect username / password !'
            return render_template('login.html', msg = msg)
    else:
        return render_template('login.html', msg=msg)

@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('username', None)
    session.pop('email', None)
    return redirect(url_for('login'))
    
@app.route('/burnout', methods=['GET', 'POST'])
def burnout():
    msg =''
    ans =''
    if request.method =='POST':
        eval = request.form['eval']
        pcount = request.form['pcount']
        avghrs = request.form['avghrs']
        workingYrs = request.form['workingYrs']
        accidents = request.form['accidents']
        turnover = request.form['turnover']
        promotion = request.form['promotion']
        salary = request.form['salary']
        dept = request.form['dept']

        emp = pickle.load(open("emp_burnout.pkl", "rb"))

        data = [[eval, pcount, avghrs, workingYrs, accidents, turnover, promotion, salary, dept]]
        pred = emp.predict(data)

        print(pred)

        if pred<=0.25:
            ans = '0'
            msg = 'Least Satisfied'
        elif pred>0.25 and pred<=0.50:
            ans = '1'
            msg = 'Moderately Satisfied'
        elif pred>0.50 and pred<=0.75:
            ans = '2'
            msg = 'Satisfied well'
        else :
            ans ='3'
            msg ='Extremely Satisfied'
        
        return render_template('employeeBurnout.html', msg=msg, ans=ans)


    return render_template("employeeBurnout.html", msg=msg, ans=ans)


@app.route('/resource')
def resource():
    return render_template('resource.html')

@app.route('/journal', methods= ['GET', 'POST'])
def journal():

    msg = ''
    if request.method == 'POST':
        text = original = request.form['entry']

        from datetime import datetime
        now = datetime.now()
        formatted_date = now.strftime('%Y-%m-%d %H:%M:%S')

        #preprocess the incoming text

        text = str(text).lower()#Convert into lower case
        #remove all charac except alphabets
        text = re.sub('^[a-zA-Z]',' ',text)
        #remove punctuation
        text= re.sub('[^\w\s]', '', text)
        text = re.sub('\d+', '',text)
        text = re.sub(',', ' ', text)


        #Tokenizing &Lemmatization

        lemmatizer = WordNetLemmatizer()
        lem_words = []
        tokens = word_tokenize(text)

        for token in tokens:
            if token not in stop_words:
                #print(token)
                #print(get_wordnet_pos(token))
                lemmetized_word = lemmatizer.lemmatize(token, get_wordnet_pos(token))
                lem_words.append(lemmetized_word)

        #REMOVE LETTERS IF ANY AFTER CLEANING 
        lem_words = [i for i in lem_words if len(i)>2]
        text = ' '.join(lem_words)

        #pickle files
        Count_Vect_ = pickle.load(open("count_vect_svm.pkl", "rb"))
        Transformer_ = pickle.load(open("transformer_svm.pkl", "rb"))
        SVM_tf = pickle.load(open("model_svm.pkl", "rb"))

        #Predict probabilities with TF-IDF(SVM), RF
        counts = Count_Vect_.transform([text])
        counts = Transformer_.transform(counts)
        tfidf_svm= SVM_tf.predict_proba(counts)

        #Vader sentiment Analysis for predicting positive Sentences.
        vad_pred = Vader_sentiment_scores(text)
        print("Vader predicted: "+ vad_pred)

        msg = vad_pred

        if not vad_pred == "Positive":
            #Classification
            classes=['Anger Management' ,'Behavioral Change', 'Counseling Fundamentals',
                    'Depression' ,'Family Conflict' ,'Intimacy', 'LGBTQ',
                    'Marriage', 'Parenting', 'Relationship Dissolution', 'Relationships',
                    'Self-esteem' ,'Sleep Improvement' ,'Social Relationships' ,'Stress/Anxiety',
                    'Substance Abuse/Addiction' ,'Trauma/Grief/Loss', 'Workplace issues']
        
            #Prediction of label
            maxpos = tfidf_svm.argmax()
            label=classes[maxpos]
            print("Label predicted: "+label)
        
            msg = label

        email = session['email']
        cursor.execute('INSERT INTO pred_data VALUES (NULL, %s, %s, %s, %s)', (email, formatted_date, original, msg, ))

        return render_template('journal.html', msg = msg)
    
    return render_template('journal.html', msg = msg)    


@app.route('/personality', methods= ['GET', 'POST'])
def personality():
    msg = ''
    if request.method=='POST':
        print('YES')
        q1 = request.form['q1']
        q2 = request.form['q2']
        q3 = request.form['q3']
        q4 = request.form['q4']
        q5 = request.form['q5']
        q6 = request.form['q6']
        q7 = request.form['q7']
        q8 = request.form['q8']
        q9 = request.form['q9']
        q10 = request.form['q10']
        q11 = request.form['q11']
        q12 = request.form['q12']
        q13 = request.form['q13']
        q14 = request.form['q14']
        q15 = request.form['q15']
        q16 = request.form['q16']
        q17 = request.form['q17']
        q18 = request.form['q18']
        q19 = request.form['q19']
        q20 = request.form['q20']

        questions = []
        questions.extend([q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20] )

        count_a =0
        count_b =0
        count = 0

        personality_dichotomy = ''

        for ques in questions:
            if ques=="1":
                count_a+=1
            elif ques=="2":
                count_b+=1
            count +=1

            if count==5:
                if count_a > count_b:
                    personality_dichotomy = personality_dichotomy + 'E '
                else:
                    personality_dichotomy = personality_dichotomy + 'I '
            
            if count == 10:
                if count_a > count_b:
                    personality_dichotomy = personality_dichotomy + 'S '
                else:
                    personality_dichotomy = personality_dichotomy + 'N '
            
            if count == 15:
                if count_a > count_b:
                    personality_dichotomy = personality_dichotomy + 'T '
                else:
                    personality_dichotomy = personality_dichotomy + 'F '
        
            if count == 20:
                if count_a > count_b:
                    personality_dichotomy = personality_dichotomy + 'J '
                else:
                    personality_dichotomy = personality_dichotomy + 'P '

        msg = personality_dichotomy
        return render_template('personality.html', msg = msg)

    return render_template('personality.html', msg = msg)

@app.route('/userRecords')
def userRecords():
    email = session['email']
    name = session['username']
    cursor.execute('Select * from pred_data where email = %s',(email,))
    value = cursor.fetchall()
    return render_template('userRecords.html', data=value, name=name)

@app.route('/register', methods =['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST':
        username = request.form['name']
        password = request.form['pwd']
        conf_password = request.form['conf_pwd']
        email = request.form['email']
        age = request.form['age']
        gender = request.form['gender']
        

        cursor.execute('SELECT * FROM users_data WHERE email = %s ', (email, ))
        account = cursor.fetchone()
        
        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[A-Za-z]+', username):
            msg = 'Name must contain only characters without spaces !'
        elif not re.match(r'[0-9]+', age):
            msg = 'Age Must have Numeric Input!'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address !'
        
        elif len(password)<8:
            msg = 'Password must contain atleast 8 characters !'
        elif not re.match(r'^(?=.*[a-z])', password):
            msg = 'Password must contain atleast one lowercase letter !'
        elif not re.match(r'^(?=.*[A-Z])', password):
            msg = 'Password must contain atleast one uppercase letter !'
        elif not re.match(r'^(?=.*?[0-9])', password):
            msg = 'Password must contain atleast one digit !'
        elif not re.match(r'^(?=.*?[#?!@$%^&*-])', password):
            msg = 'Password must contain atleast one special character !'

        elif not conf_password == password:
            msg = 'Confirm Password must match the original Password'
        
        else:
            
            cursor.execute('INSERT INTO users_data VALUES (NULL, %s, %s, %s, %s, %s)', (username, age, gender, email, password, ))
            conn.commit()
            msg = 'You have successfully registered !'
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return render_template('register.html', msg = msg)

if __name__ == '__main__':
    app.run(debug = True)
